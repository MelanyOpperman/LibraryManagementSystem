module.exports = {
    findOne: async (Model, filter, options = {}, next) => {
        try {
            if (Object.keys(options).length) {
                if (options?.populate) {
                    return await Model.findOne(filter, {}, { sort: { 'createdAt': -1 } }).populate(options.populate);
                }
            }
            return await Model.findOne(filter, {}, { sort: { 'createdAt': -1 } });
        } catch (error) {
            if (next) next(error);
            else throw error;
        }
    },
    findAll: async (Model, filter = {}, options = {}, next) => {
        try {
            if (Object.keys(options).length) {
                if (options?.populate) {
                    console.log('populate');
                    return await Model.find(filter).populate(options.populate);
                }
            }
            return await Model.find(filter);
        } catch (error) {
            if (next) next(error);
            else throw error;
        }
    },
    create: async (Model, body, next) => {
        try {
            return await Model.create(body);
        } catch (error) {
            if (next) next(error);
            else throw error;
        }
    },
    delete: async (Model, filter, next) => {
        try {
            return await Model.deleteOne(filter); // Changed from `remove` to `deleteOne`
        } catch (error) {
            if (next) next(error);
            else throw error;
        }
    },
    update: async (Model, body, filter, next) => {
        try {
            return await Model.updateOne(filter, { $set: body }); // Changed from `update` to `updateOne`
        } catch (error) {
            if (next) next(error);
            else throw error;
        }
    }
};
