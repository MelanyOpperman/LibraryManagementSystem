const {bookService, fineService, borrowerService, returnService} = require("../services");

module.exports = {
    displayBooks: async (req, res, next) => {
        const books = await bookService.getAllBooks(next);
        res.render("pages/books", {books});
    },
    addBookForm: function (req, res, next) {
        res.render('form/add-book');
    },
    addBook: async function (req, res, next) {
        console.log(req.body);
    
        try {
            const result = await bookService.addBook(req.body, next);
            res.redirect("/book");
        } catch (e) {
            // Handle the error if book creation fails
            console.log(e.toString());
        }
    },
    purchaseBook: async (req, res, next) => {
        const { bookId } = req.params;
        const userId = req.userId;
        const alreadyPurchased = await borrowerService.findPurchaseBookById(userId, bookId, next);
        if (alreadyPurchased && alreadyPurchased?.active) {
            // then show error
            res.locals.message = "User has already borrowed this book";
            res.redirect("/book");
        }

        const book = await bookService.findBookById(bookId, next);
        if (!book) {
            // then show error
            res.locals.message = `The Book id does not exist.`;
            res.redirect("/book");
        }
        if (book && book?.quantity <= 0) {
            // then show error
            res.locals.message = `Not sufficient book: ${book.book_name} to Borrow`;
            res.redirect("/book");
        }
        
        book.quantity -= 1;
        await borrowerService.purchaseBook({ userId, bookId }, next);
        res.locals.message = `Successfully purchased book ${book.book_name}`;
        res.redirect("/book");
    },
    returnBook: async (req, res, next) => {
        const userId = req.userId;
        const { bookId } = req.params;
        const purchasedBook = await borrowerService.findPurchaseBookById(userId, bookId, next);
        console.log('purchasedBook', purchasedBook)
        if (purchasedBook && !purchasedBook?.active) {
            // book is already returned
            res.locals.message = "This Book has already been returned.";
            return res.redirect("/user/profile");
        }

        const book = await bookService.findBookById(bookId, next);
        console.log('book', book)
        if (!book) {
            // then show error
            res.locals.message = `Book id does not exist.`;
            res.redirect("/user/profile");
        }

        purchasedBook.active = false;
        await borrowerService.updateBorrowerBook(userId, bookId, { active: false }, next);

        const date1 = new Date(purchasedBook.purchaseDate);
        const date2 = new Date();
        const diffTime = Math.abs(date2 - date1);
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

        // add entry to return service
        await returnService.returnBook({ userId, bookId }, next);

        // calculate fine
        if (diffDays <= 7) {
            try {
                await fineService.createFine({ userId }, next);
            } catch (e) {
                console.log(e.toString())
            }
            return res.redirect("/user/profile");
        }
        // for every day R10 is fined
        const getTotalFine = (diffDays/ 7) * 70;

        await fineService.createFine({ userId, amount: getTotalFine }, next);
        res.redirect("/user/profile");
    }
    
}